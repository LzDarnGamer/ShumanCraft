﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using System.IO;
using UnityEngine.UI;
public class GameSetupController : MonoBehaviour
{
    void Start() {
        CreatePlayer();
    }

   private void CreatePlayer() {
        PhotonNetwork.Instantiate(Path.Combine("PhotonPrefabs", "FPSController"),
            Vector3.zero, Quaternion.identity);

    }
}
